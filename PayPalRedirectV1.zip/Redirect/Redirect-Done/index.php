<title>Redirect Test</title>
<center>
<br/>
<h1>Redirect Test Done :) </h1>
<p style='font-size: 32px'>Go to <a href="https://www.paypal.com/" target="_blank"> PayPal </a></p>
<p>&copy;2018 TEST REDIRECT PAGE</p>
<p>Contact: <a href="https://www.facebook.com/messages/t/4RTMIR" target="_blank"> Facebook </a>, <a href="Gmail.php"> Gmail</a> </p>
</center>